//
//  File.swift
//  aaaa
//
//  Created by Tech on 2020-02-06.
//  Copyright © 2020 Tech. All rights reserved.
//

import Foundation

class Cat{
    var name:String{
        willSet(newValue){
            print(self.name+"will be changed to "+newValue)
        }
    };
    var owner:String{
        willSet(newValue){
            print(self.owner+"will be changed to "+newValue)
        }
    };
    var breed:String{
        willSet(newValue){
            print(self.breed+"will be changed to "+newValue)
        }
    };
    var age:Int{
        willSet(newValue){
            print("\(age)will be changed to \(newValue) ")
        }
    };
    
    
    init(name:String, owner:String, breed:String, age:Int){
        self.name=name;
        self.owner=owner;
        self.breed=breed;
        self.age=age;
    }
    
    func meow(){
        print("Meow! Meow!");
    }
    
    func printHello(x:Int, y:Int)->Int{
        return x+y;
    }
    func incrementAge(age:Int, incAmt:Int)->String{
        return String(age + incAmt)
    }
    
}
