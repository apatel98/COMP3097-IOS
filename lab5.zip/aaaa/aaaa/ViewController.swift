//
//  ViewController.swift
//  aaaa
//
//  Created by Tech on 2020-02-06.
//  Copyright © 2020 Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    let x = Cat(name: "Chava",owner: "Kevin",breed: "Mixed",age: 13);
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("trace message: viewDidload");
        print(x.printHello(x: 2,y: 2));
    }
    
    @IBOutlet weak var labelWelcome: UILabel!
    
    @IBOutlet weak var catNameTF: UITextField!
    @IBOutlet weak var catAgeTF: UITextField!
    @IBOutlet weak var catBreedTF: UITextField!
    @IBOutlet weak var catOwnerTF: UITextField!
    
    @IBAction func incrementAgeButton(_ sender: Any) {
        let a:String = x.incrementAge(age: 3, incAmt: 4)
        catAgeTF.text = a;
    }
}

