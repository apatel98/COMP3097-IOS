//
//  ViewController.swift
//  ReallyAngryBirds
//
//  Created by Tech on 2020-01-09.
//  Copyright © 2020 Appfish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

