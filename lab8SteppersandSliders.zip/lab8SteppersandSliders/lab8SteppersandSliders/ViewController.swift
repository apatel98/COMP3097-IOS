//
//  ViewController.swift
//  lab8SteppersandSliders
//
//  Created by Tech on 2020-03-02.
//  Copyright © 2020 KevinTeran. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var stepperOutput: UILabel!
    @IBOutlet weak var sliderDisplayLabel: UILabel!
    @IBOutlet weak var stepperOutlet: UIStepper!
    @IBOutlet weak var sliderOutlet: UISlider!
    
    
    @IBAction func stepperAction(_ sender: UIStepper) {
        stepperOutput.text = String(sender.value)
        sliderOutlet.value = Float(sender.value)
        sliderDisplayLabel.text = String(sender.value);
    }
    

    @IBAction func sliderAction(_ sender: UISlider) {
        sliderDisplayLabel.text = String(sender.value);
        stepperOutlet.value = Double(sender.value)
        stepperOutput.text = String(sender.value)
    }
}

