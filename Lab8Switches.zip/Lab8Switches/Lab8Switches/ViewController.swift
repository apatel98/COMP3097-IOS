//
//  ViewController.swift
//  Lab8Switches
//
//  Created by Tech on 2020-03-02.
//  Copyright © 2020 KevinTeran. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var dataSwitch: UISwitch!
    @IBOutlet weak var phoneSwitch: UISwitch!
    
    
    @IBOutlet weak var cellPhoneStatusLabel: UILabel!
    @IBOutlet weak var dataStatusLabel: UILabel!
    
    @IBAction func turnAirportModeOn(_ sender: Any) {
        dataSwitch.isOn = false;
        phoneSwitch.isOn = false;
        cellPhoneStatusLabel.text = "CELL PHONE OFF"
        dataStatusLabel.text = "DATA OFF"
    }
    

    @IBAction func turnAirportModeOff(_ sender: Any) {
        dataSwitch.isOn = true;
        phoneSwitch.isOn = true;
        cellPhoneStatusLabel.text = "CELL PHONE ON";
        dataStatusLabel.text = "DATA ON";
    }
    @IBAction func dataSwitchOnOff(_ sender: Any) {
        if(dataSwitch.isOn){
            dataStatusLabel.text = "DATA ON"
        } else{
            dataStatusLabel.text = "DATA OFF"
        }
    }
    @IBAction func phoneSwitchOnOff(_ sender: Any) {
        if(phoneSwitch.isOn){
            cellPhoneStatusLabel.text = "CELL PHONE On"
        } else{
            cellPhoneStatusLabel.text = "CELL PHONE OFF"
        }
    }
}

