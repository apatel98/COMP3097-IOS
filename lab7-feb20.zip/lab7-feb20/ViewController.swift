//
//  ViewController.swift
//  lab7-feb20
//
//  Created by Tech on 2020-02-20.
//  Copyright © 2020 Tech. All rights reserved.
//  Panel A

import UIKit

class ViewController: UIViewController {

    var x = StudentINFO()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var studentName: UILabel!
    @IBOutlet weak var gpa: UILabel!
    
    @IBAction func actionButton(_ sender: Any) {
        
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var x = StudentINFO()
        x.sName = studentName.text!
        x.gpa = gpa.text!
        
        let page2=segue.destination as! PanelBViewController
        page2.aStudent = x
    }


}

