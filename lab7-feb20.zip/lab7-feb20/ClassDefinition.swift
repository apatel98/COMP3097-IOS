//
//  ClassDefinition.swift
//  lab7-feb20
//
//  Created by Tech on 2020-02-20.
//  Copyright © 2020 Tech. All rights reserved.
//

import Foundation

class StudentINFO{
    var sName:String="";
    var gpa:String="";
}
