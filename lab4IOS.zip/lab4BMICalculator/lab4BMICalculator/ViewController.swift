//
//  ViewController.swift
//  lab4BMICalculator
//
//  Created by Tech on 2020-01-30.
//  Copyright © 2020 gbc. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var HeightInput: UITextField!
    
    @IBOutlet weak var WeightInput: UITextField!
    
    var height: Double = 0;
    var weight: Double = 0;
    var BMI: Double = 0;
    

    @IBAction func calculateBTN(_ sender: Any) {
        print("The button has been clicked!")
        //HeightInput.text = WeightInput.text
        TitleLabel.text = "Title label changed"
        ResultLabel.text = "Result label changed"
        height = Double(HeightInput.text!)!
        weight = Double(WeightInput.text!)!
        BMI = weight/(height * height)
        
        //ResultLabel.text = "Your BMI is " + String(BMI)
        if BMI<=15{
            ResultLabel.text = "Your BMI is " + String(BMI)+", you are severly underweight."
        }
    }
    
    
    @IBOutlet weak var TitleLabel: UILabel!
    @IBOutlet weak var ResultLabel: UILabel!
}

