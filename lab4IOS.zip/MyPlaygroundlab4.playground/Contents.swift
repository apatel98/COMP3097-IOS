import UIKit

var playerAccount = 100
//var playerGuess = 65
//var computerGuess = 60
var player = "Joe"
var playerAge = 25

var playerGuess = Int.random(in: 1...100)
var computerGuess = Int.random(in:1...100)

print("What is your name?")
print(player, "I see. That is quite the boring name");
print("How old are you?")
print(player, "Guess a number. If you guess higher than my number, you will win! Isn't that easy?");
var keepGoing = true

while keepGoing{
    if playerAccount <= 0{
        keepGoing = false
        break
    }
    
    print("Your guess:", playerGuess)
    print(playerGuess)
    print("Computer guess:", computerGuess)
    print(playerGuess)
    
    if(playerGuess<=computerGuess){
        print("Sorry,", player," I win!!")
        playerAccount -= 100;
        print("player account:", playerAccount);
        
    } else{
        print("Marvellous, ",player,"YOU win!!")
        playerAccount+=100;
        print("As to your Prize, honestly ", player, "by the sweet age of ", playerAge," you should know better than to believe everything everyone tells you")
        
    }
    
}


