//
//  ViewController.swift
//  Helllo World
//
//  Created by Tech on 2020-01-09.
//  Copyright © 2020 Appfish. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBAction func submit(_ sender: Any) {
        print("Hello World")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()


    }


}

