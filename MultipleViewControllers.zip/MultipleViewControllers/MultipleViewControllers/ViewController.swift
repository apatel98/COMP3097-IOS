//
//  ViewController.swift
//  MultipleViewControllers
//
//  Created by Tech on 2020-02-10.
//  Copyright © 2020 thestudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var outputTextfield: UITextField!
    @IBAction func button1(_ sender: Any) {
    }
}

